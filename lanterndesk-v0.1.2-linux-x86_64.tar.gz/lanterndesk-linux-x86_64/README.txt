LanternDesk — Ubuntu 24.04+ / Linux x86_64
Run ./lanterndesk from this directory. Keep the data/ and lib/ folders beside it.
Runtime packages: libgtk-3-0t64 libasound2t64 libpulse0 libgstreamer-plugins-base1.0-0 libayatana-appindicator3-1
Wayland screen sharing additionally needs a working xdg-desktop-portal and gstreamer1.0-pipewire.
Built with software codecs; hardware video acceleration is not enabled in this build.
